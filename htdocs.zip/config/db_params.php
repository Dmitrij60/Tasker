<?php
return array(
    'host' => 'localhost',
    'dbname' => 'tasker',
    'user' => 'root',
    'password' => '',
);